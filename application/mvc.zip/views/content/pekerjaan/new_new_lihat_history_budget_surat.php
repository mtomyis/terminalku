<!DOCTYPE html>
<html>
<head>
  <title>Surat Sp2d</title>
  <!--< ?php header("Location: '<?php echo $data; ?>'"); ?>-->
</head>
<body>
    <!--<iframe src="https://docs.google.com/gview?embedded=true&url=http://simanis.konseparsitek.com/upload/surat/2020_07_14_11_07_44_1594699664.pdf" type="application/pdf&embedded=true" style="width:100%; height:700px;" ></iframe>-->
</body>
</html>
