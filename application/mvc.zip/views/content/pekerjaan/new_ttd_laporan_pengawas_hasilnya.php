<div class="wrapper container-fluid">
    <div class='alert alert-success'>
    	<?php
		echo $status;
		?>
	</div>
	<br>
     <a class="btn btn-sm btn-success" href="<?php echo site_url('login'); ?>">Selesai</a>
</div>