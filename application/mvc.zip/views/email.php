<!DOCTYPE html>

<html>

<head>

    <meta charset="utf-8" />

    <title>UJI COBA</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

</head>

<body>

<div>

     <div style="font-size: 26px;font-weight: 700;letter-spacing: -0.02em;line-height: 32px;color: #41637e;font-family: sans-serif;text-align: center" align="center" id="emb-email-header"><img style="border: 0;-ms-interpolation-mode: bicubic;display: block;Margin-left: auto;Margin-right: auto;width: 200px; margin-top:20px; margin-bottom:20px; height:auto;" src="<?php echo base_url();?>aset/img/fav.png" alt="" width="152" height="108"></div>

   









</div>

</body>

</html>