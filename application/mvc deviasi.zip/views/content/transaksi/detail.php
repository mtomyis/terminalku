<div class="row">
	<div class="col-md-12">
			<div class="d-form">
			
			<div class="d-form-title">
				<h1 class="d-title"><img class="img-fluid img-title" src="<?php echo base_url();?>aset/icon/icon_pengeluaran.png">PERMOHONAN PENGAJUAN KEBUTUHAN MATERIAL</h1>
			</div>
			<div class="d-form-in permohonan">
				
			<div class="preview-document">
				<iframe src="http://docs.google.com/viewer?url=<?php echo base_url().$filename;?>&embedded=true" width="100%" height="100%" frameborder="0" style="border: none; background-color:transparent">
				</iframe>
			</div>
			</div>

		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$('html, body').css('overflowY', 'hidden'); 
	});
</script>