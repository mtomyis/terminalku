<div class="row">
  <div class="container-fluid">
    tes
  </div><!--/. container-fluid -->
</div>